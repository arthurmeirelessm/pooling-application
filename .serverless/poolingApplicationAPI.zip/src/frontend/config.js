// config.js
window.config = {
    ACCESS_KEY: 'AKIAYBJEMRDRZOPJHQCU', 
    SECRET_KEY: '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',
    TRANSFER_ENDPOINT: 'https://pooling-application-bucket.s3-accelerate.amazonaws.com.com'
};
