import json 

class ConsumerService:
    def __init__(self):
        pass 
    
    def consumer(self, bucket, object):
            print(bucket)
            print(object)
            return object
            

